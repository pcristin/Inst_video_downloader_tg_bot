import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union
from urllib.parse import urlparse

from instagrapi.exceptions import (
    AlbumConfigureError,
    AlbumNotDownload,
    AlbumUnknownFormat,
)
from instagrapi.mixins.crossposting import FbDestinationType
from instagrapi.types import Location, Media, Track, Usertag
from instagrapi.utils.serialization import dumps
from instagrapi.utils.timing import date_time_original
from instagrapi.utils.upload import with_coauthor_user_ids


class DownloadAlbumMixin:
    """
    Helper class to download album
    """

    def album_download(self, media_pk: int, folder: Path = "", overwrite: bool = True) -> List[Path]:
        """
        Download your album

        Parameters
        ----------
        media_pk: int
            PK for the album you want to download
        folder: Path, optional
            Directory in which you want to download the album, default is ""
            and will download the files to working directory.
        overwrite: bool, optional
            Whether to overwrite existing files. When False, existing files are returned as-is and not downloaded again.

        Returns
        -------
        List[Path]
            List of path for all the files downloaded
        """
        media = self.media_info(media_pk)
        assert media.media_type == 8, "Must been album"
        paths = []
        for resource in media.resources:
            filename = f"{media.user.username}_{resource.pk}"
            if resource.media_type == 1:
                paths.append(
                    self.photo_download_by_url(
                        resource.thumbnail_url,
                        filename,
                        folder,
                        overwrite=overwrite,
                    )
                )
            elif resource.media_type == 2:
                paths.append(
                    self.video_download_by_url(
                        resource.video_url,
                        filename,
                        folder,
                        overwrite=overwrite,
                    )
                )
            else:
                raise AlbumNotDownload('Media type "{resource.media_type}" unknown for album (resource={resource.pk})')
        return paths

    def album_download_by_urls(self, urls: List[str], folder: Path = "", overwrite: bool = True) -> List[Path]:
        """
        Download your album using specified URLs

        Parameters
        ----------
        urls: List[str]
            List of URLs to download media from
        folder: Path, optional
            Directory in which you want to download the album, default is ""
            and will download the files to working directory.
        overwrite: bool, optional
            Whether to overwrite existing files. When False, existing files are returned as-is and not downloaded again.

        Returns
        -------
        List[Path]
            List of path for all the files downloaded
        """
        paths = []
        for url in urls:
            file_name = urlparse(url).path.rsplit("/", 1)[1]
            if file_name.lower().endswith((".jpg", ".jpeg")):
                paths.append(self.photo_download_by_url(url, file_name, folder, overwrite=overwrite))
            elif file_name.lower().endswith(".mp4"):
                paths.append(self.video_download_by_url(url, file_name, folder, overwrite=overwrite))
            else:
                raise AlbumUnknownFormat()
        return paths

    def album_download_origin(self, media_pk: int) -> List[bytes]:
        """
        Download your album

        Parameters
        ----------
        media_pk: int
            PK for the album you want to download
        Returns
        -------
        List[Path]
            List of path for all the files downloaded
        """
        media = self.media_info(media_pk)
        assert media.media_type == 8, "Must been album"
        files = []
        for resource in media.resources:
            if resource.media_type == 1:
                files.append(self.photo_download_by_url_origin(resource.thumbnail_url))
            elif resource.media_type == 2:
                files.append(self.video_download_by_url_origin(resource.video_url))
            else:
                raise AlbumNotDownload('Media type "{resource.media_type}" unknown for album (resource={resource.pk})')
        return files


class UploadAlbumMixin:
    def album_upload(
        self,
        paths: List[Path],
        caption: str,
        usertags: Union[List[Usertag], List[List[Usertag]]] = [],
        location: Location = None,
        configure_timeout: int = 3,
        configure_handler=None,
        configure_exception=None,
        to_story=False,
        extra_data: Dict[str, object] = {},
        schedule_at: Optional[Union[int, datetime]] = None,
        coauthor_user_ids: Optional[List[Union[int, str]]] = None,
        share_to_facebook: bool = False,
        share_to_threads: bool = False,
        fb_destination_id: Optional[str] = None,
        fb_destination_type: Optional[FbDestinationType] = None,
        fb_validation_bypass: Optional[List[str]] = None,
        threads_destination_id: Optional[str] = None,
        threads_validation_bypass: Optional[List[str]] = None,
    ) -> Media:
        """
        Upload album to feed

        Parameters
        ----------
        paths: List[Path]
            List of paths for media to upload
        caption: str
            Media caption
        usertags: List[Usertag] or List[List[Usertag]], optional
            List of users to tag. A flat list tags the first carousel item for backward compatibility.
            Use a nested list to tag each carousel item by index: ``usertags[0]`` applies to ``paths[0]``.
        location: Location, optional
            Location tag for this upload, default is none
        configure_timeout: int
            Timeout between attempt to configure media (set caption, etc), default is 3
        configure_handler
            Configure handler method, default is None
        configure_exception
            Configure exception class, default is None
        to_story: bool
            Currently not used, default is False
        extra_data: Dict[str, str], optional
            Dict of extra data, if you need to add your params, like {"share_to_facebook": 1}.
        schedule_at: int or datetime, optional
            Unix timestamp in seconds or datetime when the album should be published.
        coauthor_user_ids: List[int | str], optional
            Instagram user IDs to invite as post coauthors.
        share_to_facebook: bool, optional
            Share this album to a linked Facebook account/page.
        share_to_threads: bool, optional
            Share this album to the linked Threads profile.
        fb_destination_id: str, optional
            Explicit Facebook destination id.
        fb_destination_type: Literal["USER", "PAGE"], optional
            Explicit Facebook destination type.
        fb_validation_bypass: List[str], optional
            Android Facebook cross-post validation bypass reasons.
        threads_destination_id: str, optional
            Explicit Threads profile id.
        threads_validation_bypass: List[str], optional
            Android Threads cross-post validation bypass reasons.

        Returns
        -------
        Media
            An object of Media class
        """
        if not paths:
            raise AlbumUnknownFormat("Album upload requires at least one media path.")
        extra_data = with_coauthor_user_ids(extra_data, coauthor_user_ids)
        extra_data = self._scheduled_extra_data(extra_data, schedule_at)
        extra_data = self._media_crossposting_extra_data(
            extra_data,
            share_to_facebook=share_to_facebook,
            share_to_threads=share_to_threads,
            fb_destination_id=fb_destination_id,
            fb_destination_type=fb_destination_type,
            fb_validation_bypass=fb_validation_bypass,
            threads_destination_id=threads_destination_id,
            threads_validation_bypass=threads_validation_bypass,
        )
        children = []
        for path in paths:
            path = Path(path)
            if path.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp"):
                upload_id, width, height = self.photo_rupload(path, to_album=True)
                children.append(
                    {
                        "upload_id": upload_id,
                        "edits": dumps(
                            {
                                "crop_original_size": [width, height],
                                "crop_center": [0.0, -0.0],
                                "crop_zoom": 1.0,
                            }
                        ),
                        "extra": dumps({"source_width": width, "source_height": height}),
                        "scene_capture_type": "",
                        "scene_type": None,
                    }
                )
            elif path.suffix.lower() == ".mp4":
                upload_id, width, height, duration, thumbnail = self.video_rupload(path, to_album=True)
                children.append(
                    {
                        "upload_id": upload_id,
                        "clips": dumps([{"length": duration, "source_type": "4"}]),
                        "extra": dumps({"source_width": width, "source_height": height}),
                        "length": duration,
                        "poster_frame_index": "0",
                        "filter_type": "0",
                        "video_result": "",
                        "date_time_original": date_time_original(time.localtime()),
                        "audio_muted": "false",
                    }
                )
                self.photo_rupload(thumbnail, upload_id)
            else:
                raise AlbumUnknownFormat(f'Unsupported album media format "{path.suffix}" for "{path.name}".')

        for attempt in range(50):
            self.logger.debug(f"Attempt #{attempt} to configure Album: {paths}")
            time.sleep(configure_timeout)
            try:
                configured = (configure_handler or self.album_configure)(
                    children, caption, usertags, location, extra_data=extra_data
                )
            except Exception as e:
                if "Transcode not finished yet" in str(e):
                    """
                    Response 202 status:
                    {"message": "Transcode not finished yet.", "status": "fail"}
                    """
                    time.sleep(configure_timeout)
                    continue
                raise e
            else:
                if configured:
                    return self._extract_configured_media_or_raise(
                        configured,
                        configure_exception or AlbumConfigureError,
                        "Album upload",
                    )
        raise (configure_exception or AlbumConfigureError)(response=self.last_response, **self.last_json)

    def album_upload_with_music(
        self,
        paths: List[Path],
        caption: str,
        track: Union[Track, Dict],
        usertags: Union[List[Usertag], List[List[Usertag]]] = [],
        location: Location = None,
        configure_timeout: int = 3,
        configure_handler=None,
        configure_exception=None,
        to_story=False,
        extra_data: Dict[str, str] = {},
        audio_asset_start_time: Optional[int] = None,
        overlap_duration: int = 30000,
        browse_session_id: Optional[str] = None,
        alacorn_session_id: Optional[str] = None,
        schedule_at: Optional[Union[int, datetime]] = None,
        **kwargs,
    ) -> Media:
        """
        Upload a feed album/carousel with attached music.

        Parameters
        ----------
        paths: List[Path]
            List of paths for media to upload.
        caption: str
            Media caption.
        track: Track or dict
            Track from music search/browser response or a compatible dict.
        usertags: List[Usertag] or List[List[Usertag]], optional
            List of users to tag. A flat list tags the first carousel item for backward compatibility.
            Use a nested list to tag each carousel item by index: ``usertags[0]`` applies to ``paths[0]``.
        location: Location, optional
            Location tag for this upload.
        configure_timeout: int
            Timeout between configure attempts.
        configure_handler
            Configure handler method, default is None.
        configure_exception
            Configure exception class, default is None.
        to_story: bool
            Currently not used, default is False.
        extra_data: Dict[str, str], optional
            Additional configure params.
        audio_asset_start_time: int, optional
            Audio start time in milliseconds. Defaults to the first highlighted
            start time from the track, or 0.
        overlap_duration: int, optional
            Audio duration in milliseconds, default 30000.
        browse_session_id: str, optional
            Music browser session id.
        alacorn_session_id: str, optional
            Music browser session id returned by ``music_in_feed_audio_browser``.
            Fetched automatically when omitted.
        schedule_at: int or datetime, optional
            Unix timestamp in seconds or datetime when the album should be published.
        **kwargs
            Additional options forwarded to :meth:`album_upload`, including
            cross-posting options.

        Returns
        -------
        Media
            A Media response from the call.
        """
        data = dict(extra_data or {})
        data["music_params"] = self._feed_music_params(
            track,
            audio_asset_start_time=audio_asset_start_time,
            overlap_duration=overlap_duration,
            browse_session_id=browse_session_id,
            alacorn_session_id=alacorn_session_id,
        )
        return self.album_upload(
            paths,
            caption,
            usertags=usertags,
            location=location,
            configure_timeout=configure_timeout,
            configure_handler=configure_handler,
            configure_exception=configure_exception,
            to_story=to_story,
            extra_data=data,
            schedule_at=schedule_at,
            **kwargs,
        )

    def album_configure(
        self,
        childs: List,
        caption: str,
        usertags: Union[List[Usertag], List[List[Usertag]]] = [],
        location: Location = None,
        extra_data: Dict[str, str] = {},
    ) -> Dict:
        """
        Post Configure Album

        Parameters
        ----------
        childs: List
            List of media/resources of an album
        caption: str
            Media caption
        usertags: List[Usertag] or List[List[Usertag]], optional
            List of users to tag. A flat list tags the first carousel item for backward compatibility.
            Use a nested list to tag each carousel item by index: ``usertags[0]`` applies to ``childs[0]``.
        location: Location, optional
            Location tag for this upload, default is None
        extra_data: Dict[str, str], optional
            Dict of extra data, if you need to add your params, like {"share_to_facebook": 1}.

        Returns
        -------
        Dict
            A dictionary of response from the call
        """
        upload_id = str(int(time.time() * 1000))
        if usertags:
            if isinstance(usertags[0], list):
                for child, child_usertags in zip(childs, usertags):
                    if not child_usertags:
                        continue
                    child["usertags"] = dumps(
                        {"in": [{"user_id": tag.user.pk, "position": [tag.x, tag.y]} for tag in child_usertags]}
                    )
            else:
                child_usertags = [{"user_id": tag.user.pk, "position": [tag.x, tag.y]} for tag in usertags]
                childs[0]["usertags"] = dumps({"in": child_usertags})
        data = {
            "timezone_offset": str(self.timezone_offset),
            "source_type": "4",
            "creation_logger_session_id": self.client_session_id,
            "location": self.location_build(location),
            "caption": caption,
            "client_sidecar_id": upload_id,
            "upload_id": upload_id,
            # "location": self.build_location(name, lat, lng, address),
            "suggested_venue_position": -1,
            "device": self.device,
            "is_suggested_venue": False,
            "children_metadata": [
                {
                    "source_type": "4",
                    "timezone_offset": str(self.timezone_offset),
                    "device": dumps(self.device),
                    **child,
                }
                for child in childs
            ],
            **extra_data,
        }
        return self.private_request("media/configure_sidecar/", self.with_default_data(data))
